package com.example.honomanagement.dto;

import lombok.Data;

@Data
public class CredentialsRequest {
    private String authId;
    private String password;
}
