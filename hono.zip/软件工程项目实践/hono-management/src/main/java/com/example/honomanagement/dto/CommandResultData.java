package com.example.honomanagement.dto;

import lombok.Data;

@Data
public class CommandResultData {
    private String deviceId;
    private String commandName;
    private String status;  // "SENT"
}
