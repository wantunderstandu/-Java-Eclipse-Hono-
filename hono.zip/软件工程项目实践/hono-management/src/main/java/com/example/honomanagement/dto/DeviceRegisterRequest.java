package com.example.honomanagement.dto;

import lombok.Data;

@Data
public class DeviceRegisterRequest {
    private String deviceId;
    private String name;
    private String description;
    private Boolean enabled = true;
}

