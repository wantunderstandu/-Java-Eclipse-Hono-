package com.example.honomanagement.dto;

import lombok.Data;

@Data
public class CommandRequest {
    private String commandName;
    private String contentType = "application/json";
    private Object payload;
    private Integer timeoutSeconds = 10;
}
