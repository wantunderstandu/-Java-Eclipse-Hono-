package com.example.honomanagement.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
@RequiredArgsConstructor
public class WebClientConfig {

    private final HonoProperties honoProperties;

    @Bean
    public WebClient webClient() {
        return WebClient.builder()
                .baseUrl(honoProperties.getRegistry().getUrl())
                .defaultHeader("Content-Type", "application/json")
                .build();
    }
}