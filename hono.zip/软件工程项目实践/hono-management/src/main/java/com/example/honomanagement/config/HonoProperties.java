package com.example.honomanagement.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "hono")
public class HonoProperties {
    private String tenantId = "demo-tenant";
    private Registry registry = new Registry();

    @Data
    public static class Registry {
        private String url = "https://hono.eclipseprojects.io:28443";
    }
}
