package com.example.honomanagement.service;

import com.example.honomanagement.config.HonoProperties;
import com.example.honomanagement.dto.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class HonoDeviceService {

    private final WebClient webClient;
    private final HonoProperties honoProperties;
    private final ObjectMapper objectMapper;

    private String getTenantId() {
        return honoProperties.getTenantId();
    }

    // ========== 租户初始化（启动时自动创建） ==========
    @PostConstruct
    public void initTenant() {
        String tenantId = getTenantId();
        log.info("检查租户是否存在: {}", tenantId);
        webClient.get()
                .uri("/v1/tenants/{tenantId}", tenantId)
                .retrieve()
                .bodyToMono(Void.class)
                .onErrorResume(WebClientResponseException.NotFound.class, e -> {
                    log.warn("租户不存在，正在创建: {}", tenantId);
                    Map<String, Object> tenant = new HashMap<>();
                    tenant.put("tenantId", tenantId);
                    tenant.put("enabled", true);
                    return webClient.put()
                            .uri("/v1/tenants/{tenantId}", tenantId)
                            .bodyValue(tenant)
                            .retrieve()
                            .bodyToMono(Void.class)
                            .doOnSuccess(v -> log.info("租户创建成功: {}", tenantId));
                })
                .subscribe();
    }

    // ========== 1. 设备注册 ==========
    public Mono<DeviceRegisterRequest> registerDevice(DeviceRegisterRequest request) {
        String deviceId = request.getDeviceId();
        String tenantId = getTenantId();

        Map<String, Object> honoDevice = new HashMap<>();
        honoDevice.put("deviceId", deviceId);
        honoDevice.put("enabled", request.getEnabled() != null ? request.getEnabled() : true);

        Map<String, Object> ext = new HashMap<>();
        if (request.getName() != null) ext.put("name", request.getName());
        if (request.getDescription() != null) ext.put("description", request.getDescription());
        if (!ext.isEmpty()) {
            honoDevice.put("ext", ext);
        }

        return webClient.put()
                .uri("/v1/tenants/{tenantId}/devices/{deviceId}", tenantId, deviceId)
                .bodyValue(honoDevice)
                .retrieve()
                .bodyToMono(Map.class)
                .map(response -> {
                    log.info("设备注册成功: {}", deviceId);
                    return request;
                })
                .onErrorResume(WebClientResponseException.class, e -> {
                    log.error("设备注册失败: {}, status={}, body={}", deviceId, e.getStatusCode(), e.getResponseBodyAsString());
                    return Mono.error(new RuntimeException("设备注册失败: " + e.getResponseBodyAsString()));
                });
    }

    // ========== 2. 设备凭证配置（密码哈希 + 加盐） ==========
    public Mono<Void> configureCredentials(String deviceId, CredentialsRequest request) {
        String tenantId = getTenantId();
        String authId = request.getAuthId() != null ? request.getAuthId() : deviceId;
        String password = request.getPassword();

        String salt = generateSalt();
        String hashedPassword = hashPassword(password, salt);

        Map<String, Object> credential = new LinkedHashMap<>();
        credential.put("deviceId", deviceId);
        credential.put("authId", authId);
        credential.put("type", "hashed-password");

        List<Map<String, Object>> secrets = new ArrayList<>();
        Map<String, Object> secret = new LinkedHashMap<>();
        secret.put("hashFunction", "sha-256");
        secret.put("salt", salt);
        secret.put("value", hashedPassword);
        secrets.add(secret);
        credential.put("secrets", secrets);

        return webClient.put()
                .uri("/v1/tenants/{tenantId}/devices/{deviceId}/credentials/{authId}",
                        tenantId, deviceId, authId)
                .bodyValue(credential)
                .retrieve()
                .bodyToMono(Void.class)
                .doOnSuccess(v -> log.info("凭证配置成功: device={}, authId={}", deviceId, authId))
                .onErrorResume(WebClientResponseException.class, e -> {
                    log.error("凭证配置失败: {}, status={}, body={}", deviceId, e.getStatusCode(), e.getResponseBodyAsString());
                    return Mono.error(new RuntimeException("凭证配置失败: " + e.getResponseBodyAsString()));
                });
    }

    // ========== 3. 设备列表查询（含扩展字段） ==========
    public Mono<DeviceListData> listDevices(int page, int size) {
        String tenantId = getTenantId();

        return webClient.get()
                .uri(uriBuilder -> uriBuilder
                        .path("/v1/tenants/{tenantId}/devices")
                        .queryParam("page", page)
                        .queryParam("pageSize", size)
                        .build(tenantId))
                .retrieve()
                .bodyToMono(Map.class)
                .flatMap(response -> {
                    List<Map<String, Object>> devices = (List<Map<String, Object>>) response.get("devices");
                    if (devices == null) {
                        devices = Collections.emptyList();
                    }
                    long total = response.get("total") != null ?
                            Long.parseLong(response.get("total").toString()) : devices.size();

                    List<Mono<DeviceListData.DeviceInfo>> deviceMonos = devices.stream()
                            .map(d -> {
                                String id = d.get("deviceId").toString();
                                Boolean enabled = d.get("enabled") != null ? Boolean.parseBoolean(d.get("enabled").toString()) : true;
                                return getDeviceDetail(tenantId, id)
                                        .map(detail -> {
                                            DeviceListData.DeviceInfo info = new DeviceListData.DeviceInfo();
                                            info.setDeviceId(id);
                                            info.setEnabled(enabled);
                                            Map<String, Object> ext = (Map<String, Object>) detail.get("ext");
                                            if (ext != null) {
                                                info.setName((String) ext.get("name"));
                                                info.setDescription((String) ext.get("description"));
                                            }
                                            return info;
                                        })
                                        .onErrorResume(e -> {
                                            DeviceListData.DeviceInfo info = new DeviceListData.DeviceInfo();
                                            info.setDeviceId(id);
                                            info.setEnabled(enabled);
                                            return Mono.just(info);
                                        });
                            })
                            .collect(Collectors.toList());

                    return Mono.zip(deviceMonos, objects -> {
                        List<DeviceListData.DeviceInfo> deviceInfos = Arrays.stream(objects)
                                .map(obj -> (DeviceListData.DeviceInfo) obj)
                                .collect(Collectors.toList());
                        DeviceListData data = new DeviceListData();
                        data.setTenantId(tenantId);
                        data.setTotal(total);
                        data.setDevices(deviceInfos);
                        return data;
                    });
                });
    }

    // ========== 4. 查询单个设备状态（新增） ==========
    public Mono<DeviceListData.DeviceInfo> getDevice(String deviceId) {
        String tenantId = getTenantId();
        return getDeviceDetail(tenantId, deviceId)
                .map(detail -> {
                    DeviceListData.DeviceInfo info = new DeviceListData.DeviceInfo();
                    info.setDeviceId(deviceId);
                    Boolean enabled = detail.get("enabled") != null ?
                            Boolean.parseBoolean(detail.get("enabled").toString()) : true;
                    info.setEnabled(enabled);
                    Map<String, Object> ext = (Map<String, Object>) detail.get("ext");
                    if (ext != null) {
                        info.setName((String) ext.get("name"));
                        info.setDescription((String) ext.get("description"));
                    }
                    return info;
                })
                .onErrorResume(WebClientResponseException.NotFound.class, e -> {
                    log.warn("设备不存在: {}", deviceId);
                    return Mono.error(new RuntimeException("设备不存在: " + deviceId));
                });
    }

    // ========== 5. 获取单个设备详情（含 ext） ==========
    public Mono<Map<String, Object>> getDeviceDetail(String tenantId, String deviceId) {
        return webClient.get()
                .uri("/v1/tenants/{tenantId}/devices/{deviceId}", tenantId, deviceId)
                .retrieve()
                .bodyToMono(new ParameterizedTypeReference<Map<String, Object>>() {});
    }

    // ========== 6. 命令下发（模拟实现） ==========
    public Mono<CommandResultData> sendCommand(String deviceId, CommandRequest request) {
        log.info("下发命令: device={}, command={}, payload={}", deviceId, request.getCommandName(), request.getPayload());

        CommandResultData result = new CommandResultData();
        result.setDeviceId(deviceId);
        result.setCommandName(request.getCommandName());
        result.setStatus("SENT");
        return Mono.just(result);
    }

    // ===== 辅助方法 =====
    private String generateSalt() {
        byte[] saltBytes = new byte[16];
        new Random().nextBytes(saltBytes);
        return Base64.getEncoder().encodeToString(saltBytes);
    }

    private String hashPassword(String password, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            String salted = salt + password;
            byte[] hash = digest.digest(salted.getBytes(StandardCharsets.UTF_8));
            return Base64.getEncoder().encodeToString(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }
}