package com.example.honomanagement.controller;

import com.example.honomanagement.dto.*;
import com.example.honomanagement.service.HonoDeviceService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@RestController
@RequestMapping("/api/devices")
@RequiredArgsConstructor
public class DeviceController {

    private final HonoDeviceService honoService;

    // 1. 设备注册
    @PostMapping
    public Mono<ResponseEntity<ApiResponse<DeviceRegisterRequest>>> registerDevice(
            @RequestBody DeviceRegisterRequest request) {
        return honoService.registerDevice(request)
                .map(registered -> ResponseEntity.ok(
                        ApiResponse.success("设备注册成功", registered)))
                .onErrorResume(e -> Mono.just(
                        ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()))));
    }

    // 2. 设备凭证配置
    @PostMapping("/{deviceId}/credentials")
    public Mono<ResponseEntity<ApiResponse<Map<String, String>>>> configureCredentials(
            @PathVariable String deviceId,
            @RequestBody CredentialsRequest request) {
        return honoService.configureCredentials(deviceId, request)
                .then(Mono.defer(() -> {
                    Map<String, String> data = new java.util.HashMap<>();
                    data.put("deviceId", deviceId);
                    data.put("authId", request.getAuthId() != null ? request.getAuthId() : deviceId);
                    return Mono.just(ResponseEntity.ok(
                            ApiResponse.success("设备凭证配置成功", data)));
                }))
                .onErrorResume(e -> Mono.just(
                        ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()))));
    }

    // 3. 设备列表查询
    @GetMapping
    public Mono<ResponseEntity<ApiResponse<DeviceListData>>> listDevices(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return honoService.listDevices(page, size)
                .map(data -> ResponseEntity.ok(
                        ApiResponse.success("查询成功", data)))
                .onErrorResume(e -> Mono.just(
                        ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()))));
    }

    // 4. 命令下发
    @PostMapping("/{deviceId}/commands")
    public Mono<ResponseEntity<ApiResponse<CommandResultData>>> sendCommand(
            @PathVariable String deviceId,
            @RequestBody CommandRequest request) {
        return honoService.sendCommand(deviceId, request)
                .map(result -> ResponseEntity.ok(
                        ApiResponse.success("命令下发请求已提交", result)))
                .onErrorResume(e -> Mono.just(
                        ResponseEntity.badRequest().body(ApiResponse.error(e.getMessage()))));
    }
    // 5. 查询单个设备状态
    @GetMapping("/{deviceId}")
    public Mono<ResponseEntity<ApiResponse<DeviceListData.DeviceInfo>>> getDevice(
            @PathVariable String deviceId) {
        return honoService.getDevice(deviceId) // 需要在 Service 中实现调用 Hono GET /v1/tenants/{tenantId}/devices/{deviceId}
                .map(info -> ResponseEntity.ok(ApiResponse.success("查询成功", info)))
                .onErrorResume(e -> Mono.just(ResponseEntity.notFound().build()));
    }
}

