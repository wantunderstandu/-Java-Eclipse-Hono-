package com.example.honomanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HonoManagementApplication {

    public static void main(String[] args) {
        SpringApplication.run(HonoManagementApplication.class, args);
    }

}
