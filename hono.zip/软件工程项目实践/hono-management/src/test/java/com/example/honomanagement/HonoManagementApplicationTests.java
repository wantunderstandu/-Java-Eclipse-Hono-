package com.example.honomanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HonoManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
